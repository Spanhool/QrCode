export const Text = () => {
  return (
    <div className="w-[288px] h-[131px] p-4">
      <h2 className="w-[256] text-[#1F314F] justify-center text-center mb-4 text-xl font-bold">
        Improve your front-end skills by building projects
      </h2>
      <p className="text-[#68778D] justify-center text-center text-[15px]">
        Scan the QR code to visit Frontend Mentor and take your coding skills to
        the next level
      </p>
    </div>
  );
};
