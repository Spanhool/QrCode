export const QrCode = () => {
  return (
    <div>
      <img
        src="/images/image-qr-code.png"
        alt="Imagem"
        className=" rounded-xl"
      />
    </div>
  );
};
