import { QrCode } from "@/components/QrCode/QrCode";
import { Text } from "@/components/Text/Text";

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center">
      <div className="bg-white w-80 h-[499px] rounded-2xl pl-4 pr-4 pt-4 pb-10">
        <QrCode />
        <Text />
      </div>
    </main>
  );
}
